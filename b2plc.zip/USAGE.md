# Usage Tips

- Prefer fixed seeds for fair paired comparisons.
- For block bootstrap on time-series, try `--block_sizes 100,200,300`.
- To explore sensitivity to lambda: `--lambda_vals 0.1,0.2,0.3,0.4,0.5`.
- All outputs are CSV for easy plotting in Python/Matlab/R.
