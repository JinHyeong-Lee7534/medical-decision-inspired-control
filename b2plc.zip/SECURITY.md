# Security Policy

## Supported Versions
This repository provides simulation code only. No network-facing services are shipped.

## Reporting a Vulnerability
Please report security issues privately to **ljh7534@gmail.com**. You will receive a response within 7 business days.
