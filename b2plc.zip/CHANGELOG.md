# Changelog

All notable changes to this project will be documented in this file.

## [1.1.0] - 2025-10-28
### Added
- Initial public release of the **B2+PLC** simulation (v1.1-COMPLETE)
- Reproducibility manifest writer
- Bootstrap tests (standard + block) with Holm-Bonferroni correction
- Lambda sensitivity and ablation studies
- Effect size table (Cohen's d_z)

### Fixed
- Centralized output file names
- Function ordering issues
- Float precision warnings in pandas

## [Unreleased]
- CLI flags for figure generation
- Optional plotting utilities
