# Contributor Covenant Code of Conduct (Short)

We are committed to a harassment-free experience for everyone.

- Be respectful and constructive.
- Assume good faith; focus on technical issues.
- No harassment, trolling, or discrimination.

For major incidents, contact the maintainers via email listed in README.
