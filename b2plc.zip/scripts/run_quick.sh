#!/usr/bin/env bash
set -euo pipefail
python Final_B2plusPLC_ver1_1_COMPLETE.py --N 30000 --boot 300 --seed 4242
