# Contributing

Thanks for your interest in improving **B2+PLC — Proactive Latency Control for WebRTC GCC**!

## How to contribute
1. Fork the repo and create a feature branch: `git checkout -b feat/short-name`
2. Install dependencies: `pip install -r requirements.txt`
3. Run the quick test:
   ```bash
   python Final_B2plusPLC_ver1_1_COMPLETE.py --N 30000 --boot 300 --seed 4242
   ```
4. Format your code (optional): `black .`
5. Commit using conventional commits:
   - `feat: ...`, `fix: ...`, `docs: ...`, `refactor: ...`, etc.
6. Open a Pull Request with a clear description and reference to issues if applicable.

## Tests
This project is a simulation with deterministic seeds. Please include before/after metrics or CSVs to demonstrate correctness/regression.

## Code style
- Target Python 3.8+
- Keep functions pure and deterministic where possible (avoid global RNG).
- Prefer numpy vectorization for performance.
