# Use of AI Assistance

Portions of the statistical analysis, mathematical validation, and Python implementation were assisted by OpenAI’s ChatGPT (GPT‑5) under the author's direct supervision. The model was used to verify code reproducibility, perform numerical parameter sweeps, and refine mathematical derivations. All conceptual design, algorithmic logic, and interpretation of results were independently conceived, executed, and validated by the author.
